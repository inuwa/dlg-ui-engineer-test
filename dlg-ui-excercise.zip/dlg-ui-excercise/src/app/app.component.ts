import { Component, OnInit } from '@angular/core';
import { FeedService } from './services/feed.service';
import { FAQ } from './_/interface/faq.interface';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
    providers: [
        FeedService
    ]
})
export class AppComponent implements OnInit {
    faqs: FAQ[] = [];
    constructor(private _feedService: FeedService) {

    }

    ngOnInit() {
        this._feedService.getFAQs().subscribe((faqs: FAQ[]) => {
            this.faqs = faqs.map(faq => {
                faq['open'] = false;
                return faq;
            });
        });
    }

    $$toggle(faq: FAQ) {
        faq.open = !faq.open;
    }
}
