import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FAQ } from '../_/interface/faq.interface';
import { HttpClient } from '@angular/common/http';
import { ApiUrl } from '../_/const/api-url.enum';
@Injectable()
export class FeedService {
    constructor(private _httpClient: HttpClient) {
    }

    getFAQs(): Observable<FAQ[]> {
        return this._httpClient.get<FAQ[]>(ApiUrl.jsonserver);
    }
}