export enum ApiUrl {
    jsonserver = 'http://localhost:3000/data'
}