# DlgUiExcercise

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 9.1.9.

## Instructions

 - Clone this repository `git clone git@github.com:inuwa/dlg-ui-test.git`
 - Navigate to the folder `cd <PATH-TO-FOLDER>/dlg-ui-test`. _replace <PATH-TO-FOLDER> with the path to the cloned folder.
 - Install node_module dependencies `npm install`
 - Start the data api `npm run serve-api`
 - Open anotther terminal window and  `ng serve`. Navigate to `http://localhost:4200/`. 

## 
